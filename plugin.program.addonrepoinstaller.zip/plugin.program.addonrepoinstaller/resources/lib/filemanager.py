import xbmc
xbmc.executebuiltin('ActivateWindow(filemanager)')