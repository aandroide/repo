import xbmc
# apre la finestra “Installa da file .zip”
xbmc.executebuiltin('InstallFromZip()')
