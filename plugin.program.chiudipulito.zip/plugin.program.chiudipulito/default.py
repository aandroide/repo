# -*- coding: utf-8 -*-
"""
ChiudiPulito - Uscita pulita da Kodi
Script principale per gestire il tasto Esci
"""

import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import os

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ICON = xbmcvfs.translatePath(ADDON.getAddonInfo('icon'))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

def get_settings_info():
    """Ottiene le impostazioni correnti formattate"""
    
    # Leggi le impostazioni
    auto_exit = ADDON.getSetting('enable_auto_exit') == 'true'
    timeout = ADDON.getSetting('idle_timeout')
    warnings = ADDON.getSetting('enable_warning') == 'true'
    warning_time = ADDON.getSetting('warning_time')
    notifications = ADDON.getSetting('enable_notification') == 'true'
    sound = ADDON.getSetting('enable_sound') == 'true'
    custom_sound = ADDON.getSetting('use_custom_sound') == 'true'
    custom_sound_30sec = ADDON.getSetting('use_custom_sound_30sec') == 'true'
    
    # Traduzioni per il warning time
    warning_text = {
        '1': '1 minuto',
        '2': '2 minuti', 
        '3': '3 minuti',
        '5': '5 minuti'
    }.get(warning_time, warning_time + ' minuti')
    
    # Formatta il messaggio
    msg = "[B]Impostazioni Correnti:[/B]\n\n"
    
    if auto_exit:
        msg += f"Chiusura automatica: [B]ATTIVA[/B]\n"
        msg += f"Timeout inattività: [B]{timeout} minuti[/B]\n"
        
        if warnings:
            msg += f"Avvisi: [B]ATTIVI[/B]\n"
            msg += f"Primo avviso: [B]{warning_text} prima[/B]\n"
            msg += f"Secondo avviso: [B]30 secondi prima[/B]\n"
        else:
            msg += f"Avvisi: [COLOR red]DISATTIVATI[/COLOR]\n"
    else:
        msg += "Chiusura automatica: [B]DISATTIVA[/B]\n"
    
    msg += "\n"
    
    if notifications:
        msg += "Notifiche: [B]ATTIVE[/B]\n"
        if sound:
            msg += "Suono: [B]ATTIVO[/B]\n"
            if custom_sound and custom_sound_30sec:
                msg += "Audio personalizzato: [B]ENTRAMBI[/B]\n"
            elif custom_sound:
                msg += "Audio personalizzato: [B]Solo primo avviso[/B]\n"
            elif custom_sound_30sec:
                msg += "Audio personalizzato: [B]Solo 30 secondi[/B]\n"
            else:
                msg += "Audio: [B]Suoni standard Kodi[/B]\n"
        else:
            msg += "Suono: [COLOR red]DISATTIVATO[/COLOR]\n"
    else:
        msg += "Notifiche: [B]DISATTIVATE[/B]\n"
    
    return msg

def chiudi_kodi_con_conferma():
    """Mostra le impostazioni e chiede conferma prima di chiudere"""
    
    # Ottieni il messaggio con le impostazioni
    settings_msg = get_settings_info()
    
    # Mostra dialog con conferma
    dialog = xbmcgui.Dialog()
    conferma = dialog.yesno(
        ADDON_NAME,
        settings_msg + "\n[B]Vuoi chiudere Kodi adesso?[/B]",
        nolabel="Annulla",
        yeslabel="Chiudi Kodi"
    )
    
    if conferma:
        # L'utente ha confermato, chiudi Kodi
        xbmc.log('[ChiudiPulito] Chiusura manuale confermata dall\'utente', xbmc.LOGINFO)
        
        # Mostra notifica se abilitata
        if ADDON.getSetting('enable_notification') == 'true':
            suono_abilitato = ADDON.getSetting('enable_sound') == 'true'
            dialog.notification(
                ADDON_NAME,
                'Chiusura di Kodi in corso...',
                ADDON_ICON,
                2000,
                suono_abilitato
            )
        
        # Chiude Kodi
        xbmc.executebuiltin('Quit')
    else:
        # L'utente ha annullato
        xbmc.log('[ChiudiPulito] Chiusura manuale annullata dall\'utente', xbmc.LOGINFO)

def chiudi_kodi_diretto():
    """Chiude Kodi direttamente (per keymap)"""
    
    # Controlla se mostrare notifica
    abilita_notifica = ADDON.getSetting('enable_notification') == 'true'
    
    if abilita_notifica:
        suono_abilitato = ADDON.getSetting('enable_sound') == 'true'
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Chiusura di Kodi in corso...',
            ADDON_ICON,
            2000,
            suono_abilitato
        )
    
    # Log della chiusura
    xbmc.log('[ChiudiPulito] Chiusura diretta di Kodi avviata (keymap)', xbmc.LOGINFO)
    
    # Chiude Kodi correttamente
    xbmc.executebuiltin('Quit')

def update_settings_without_exit():
    """Aggiorna le impostazioni senza uscire dal menu"""
    try:
        # Forza un ridisegno del controllo delle impostazioni
        xbmc.executebuiltin('Action(Noop)')
        xbmc.sleep(100)
        
        # Invia un evento di aggiornamento
        xbmc.executebuiltin('UpdateLibrary(video,special://profile/addon_data/%s)' % ADDON.getAddonInfo('id'))
        xbmc.sleep(100)
        
        # Forza un refresh del container
        xbmc.executebuiltin('Container.Refresh')
        xbmc.sleep(100)
        
        xbmc.log('[ChiudiPulito] Impostazioni aggiornate senza uscire', xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f'[ChiudiPulito] Errore aggiornamento: {str(e)}', xbmc.LOGERROR)
        return False

def show_audio_selected_notification(audio_type, file_path):
    """Mostra una notifica che rimane nel menu impostazioni"""
    dialog = xbmcgui.Dialog()
    file_name = os.path.basename(file_path)
    
    # Crea un dialog di progresso personalizzato
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f'File selezionato:\n[COLOR yellow]{file_name}[/COLOR]\n\nRiproduzione in corso...')
    
    # Riproduce l'audio
    xbmc.executebuiltin(f'PlayMedia({file_path})')
    
    # Mostra per 2 secondi
    for i in range(20):
        if progress.iscanceled():
            break
        progress.update(int(i * 5))
        xbmc.sleep(100)
    
    progress.close()
    
    # Piccola notifica finale
    dialog.notification(
        ADDON_NAME,
        f'Audio impostato: {file_name}',
        ADDON_ICON,
        1500,
        False
    )

def select_audio_file_and_refresh(audio_type):
    """Seleziona un file audio e aggiorna SENZA USCIRE dal menu"""
    
    dialog = xbmcgui.Dialog()
    
    if audio_type == '1min':
        titolo = "Seleziona file audio per primo avviso"
        setting_path = 'custom_sound_path'
        setting_use = 'use_custom_sound'
    else:  # '30sec'
        titolo = "Seleziona file audio per 30 secondi"
        setting_path = 'custom_sound_30sec_path'
        setting_use = 'use_custom_sound_30sec'
    
    # Apri il file browser
    file_path = dialog.browse(
        1,  # 1 = file, 0 = cartella
        titolo,
        'files',
        mask='.mp3|.wav|.ogg'
    )
    
    if file_path and os.path.exists(file_path):
        # SALVA IL FILE
        ADDON.setSetting(setting_path, file_path)
        ADDON.setSetting(setting_use, 'true')
        
        xbmc.log(f'[ChiudiPulito] File selezionato per {audio_type}: {file_path}', xbmc.LOGINFO)
        
        # Mostra notifica SENZA USCIRE dal menu
        show_audio_selected_notification(audio_type, file_path)
        
        # Prova ad aggiornare senza uscire
        update_settings_without_exit()
        
        return True
    elif file_path:
        # Il file non esiste
        dialog.notification(
            ADDON_NAME,
            'File non trovato!',
            ADDON_ICON,
            2000,
            True
        )
        return False
    
    return False

def get_audio_file_info(audio_type):
    """Ottiene informazioni sul file audio da riprodurre (per uso interno)"""
    
    if audio_type == '1min':
        # Audio per primo avviso
        use_custom = ADDON.getSetting('use_custom_sound') == 'true'
        custom_path = ADDON.getSetting('custom_sound_path')
        default_file = 'avviso_1min.mp3'
        tipo_nome = "primo avviso"
        setting_use = 'use_custom_sound'
        setting_path = 'custom_sound_path'
    else:  # '30sec'
        # Audio per 30 secondi
        use_custom = ADDON.getSetting('use_custom_sound_30sec') == 'true'
        custom_path = ADDON.getSetting('custom_sound_30sec_path')
        default_file = 'avviso_30sec.mp3'
        tipo_nome = "30 secondi"
        setting_use = 'use_custom_sound_30sec'
        setting_path = 'custom_sound_30sec_path'
    
    # Log dettagliato
    xbmc.log(f'[ChiudiPulito] DEBUG {audio_type}: use_custom={use_custom}, custom_path="{custom_path}"', xbmc.LOGINFO)
    
    # Controlla se il percorso esiste
    percorso_valido = custom_path and custom_path.strip() != '' and os.path.exists(custom_path)
    
    # Se l'utente ha impostato audio personalizzato ma il file non esiste
    if use_custom and not percorso_valido:
        xbmc.log(f'[ChiudiPulito] Percorso non valido per {audio_type}', xbmc.LOGINFO)
        
        dialog = xbmcgui.Dialog()
        
        if custom_path and custom_path.strip():
            # C'è un percorso ma il file non esiste
            risposta = dialog.yesno(
                ADDON_NAME,
                f"File audio per {tipo_nome} non trovato:\n\n"
                f"[B]{custom_path}[/B]\n\n"
                f"Vuoi selezionare un nuovo file?",
                nolabel="Disabilita",
                yeslabel="Seleziona"
            )
        else:
            # Non c'è nessun percorso
            risposta = dialog.yesno(
                ADDON_NAME,
                f"Nessun file audio selezionato per {tipo_nome}.\n\n"
                f"Vuoi selezionare un file ora?",
                nolabel="Usa predefinito",
                yeslabel="Seleziona"
            )
        
        if risposta:
            # L'utente vuole selezionare un file
            select_audio_file_and_refresh(audio_type)
            
            # Ricarica le impostazioni dopo la selezione
            use_custom = ADDON.getSetting(setting_use) == 'true'
            custom_path = ADDON.getSetting(setting_path)
            percorso_valido = custom_path and custom_path.strip() != '' and os.path.exists(custom_path)
        else:
            # Disabilita l'audio personalizzato
            use_custom = False
            ADDON.setSetting(setting_use, 'false')
    
    # Determina il percorso del file audio
    if use_custom and percorso_valido:
        audio_path = custom_path
        audio_name = os.path.basename(custom_path)
        tipo = "Audio personalizzato"
        xbmc.log(f'[ChiudiPulito] Usando audio personalizzato per {audio_type}: {audio_path}', xbmc.LOGINFO)
    else:
        # Usa file predefinito
        default_path = os.path.join(ADDON_PATH, 'resources', 'sounds', default_file)
        
        # Se il file predefinito non esiste
        if not os.path.exists(default_path):
            xbmc.log(f'[ChiudiPulito] ERROR: File predefinito non trovato: {default_path}', xbmc.LOGERROR)
            
            # Cerca nella vecchia posizione
            old_path = os.path.join(ADDON_PATH, 'sounds', default_file)
            if os.path.exists(old_path):
                default_path = old_path
                xbmc.log(f'[ChiudiPulito] Trovato nella vecchia posizione: {old_path}', xbmc.LOGINFO)
            else:
                return None, None, None
        
        audio_path = default_path
        audio_name = default_file
        tipo = "Audio predefinito"
        xbmc.log(f'[ChiudiPulito] Usando audio predefinito per {audio_type}: {audio_path}', xbmc.LOGINFO)
    
    return audio_path, audio_name, tipo

def main():
    """Entry point principale"""
    
    # Controlla se chiamato per selezione audio
    if len(sys.argv) > 1:
        parametro = sys.argv[1] if len(sys.argv) > 1 else None
        
        # Seleziona file e refresh
        if parametro == 'select_and_refresh':
            audio_type = sys.argv[2] if len(sys.argv) > 2 else None
            if audio_type in ['1min', '30sec']:
                select_audio_file_and_refresh(audio_type)
            return
        
        # Chiamato da menu addon con handle
        try:
            handle = int(parametro)
            # Segnala a Kodi che non ci sono contenuti (evita l'errore)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            chiamato_da_menu = True
        except (ValueError, TypeError):
            chiamato_da_menu = False
    else:
        chiamato_da_menu = False
    
    # Se chiamato da menu → mostra info e chiedi conferma
    # Se chiamato da keymap → chiudi direttamente
    if chiamato_da_menu:
        chiudi_kodi_con_conferma()
    else:
        chiudi_kodi_diretto()

if __name__ == '__main__':
    main()