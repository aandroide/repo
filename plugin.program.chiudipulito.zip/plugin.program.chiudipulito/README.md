ChiudiPulito - Addon per Kodi

Ciao a tutti, volevo condividere con voi un addon per Kodi che ho creato.
Si chiama ChiudiPulito e come suggerisce il nome, serve per gestire la chiusura di Kodi in modo più "pulito" e automatizzato.

Cos'è ChiudiPulito?
È un addon che trasforma il tasto "Esci" di Kodi in qualcosa di più intelligente. Invece della semplice chiusura, ti offre varie opzioni per uscire da Kodi in modo controllato.

Le funzioni principali:
Chiusura Automatica per Inattività
Imposta un timer (es: 30 minuti). Se non usi Kodi per quel tempo, si chiude automaticamente. Perfetto per chi si dimentica acceso il TV o il PC.

Avvisi Prima della Chiusura
Ricevi un avviso qualche minuto prima (puoi scegliere: 1, 2, 3 o 5 minuti), più un secondo avviso a 30 secondi dalla chiusura. Così non rischi di perdere quello che stavi guardando.

Audio Personalizzabili
Ci sono suoni standard inclusi nell'addon, oppure puoi scegliere i tuoi file audio preferiti (.mp3, .wav, .ogg). Quando selezioni un nuovo file, lo senti subito per conferma.

Notifiche Visive
Messaggi sullo schermo per ogni avviso, con opzione per attivare o disattivare i suoni.

Come si usa?
Installazione:

Scarica il repository come ZIP

In Kodi: Addon -> Installa da file ZIP

Seleziona il file scaricato

Configurazione:

Apri le impostazioni dell'addon

Chiusura Automatica: Attiva e imposta il timeout

Avvisi: Decidi se riceverli e quando

Audio: Scegli se usare quelli predefiniti o personalizzati

Uso quotidiano:

Dal menu addon: Ti mostra le impostazioni attuali e chiede conferma

Da tasto Esci/Keymap: Chiude direttamente con notifica

Automatico: Se sei inattivo, fa tutto da solo

Perché l'ho creato?
Avevo due problemi:

Spesso mi dimenticavo Kodi acceso tutta la notte

Quando uscivo, a volte interrompevo film o serie tv senza volerlo

Con ChiudiPulito ho risolto entrambi: si chiude da solo se mi dimentico, e mi avvisa prima.

Dettagli tecnici
Scritto in Python per Kodi, supporta Kodi 19 (Matrix) e superiori. I file audio predefiniti sono inclusi nell'addon. Se si sceglie un file personalizzato, viene salvato il percorso. L'addon prova a mantenerti nel menu impostazioni durante la selezione.

Cosa include?
L'addon principale, due file audio predefiniti (avviso_1min.mp3 e avviso_30sec.mp3), supporto per audio personalizzati, interfaccia in italiano.

A chi può servire?
A chi ha bambini: si chiude da solo se lasciato inutilizzato.
A chi guarda contenuti prima di dormire: non resta acceso tutta la notte.
A chi condivide il dispositivo: gestione automatica degli spegnimenti.
A chi vuole più controllo: avvisi prima della chiusura.

È gratuito?
Sì, completamente gratuito e open source. L'ho creato per me stesso, ma se può essere utile a qualcun altro, tanto meglio.

Domande frequenti:
Q: Serve root o permessi speciali?
A: No, è un normale addon per Kodi.

Q: Funziona con tutti i skin?
A: Sì, dovrebbe funzionare con qualsiasi skin.

Q: Posso usare i miei suoni?
A: Certo! MP3, WAV, OGG - quello che preferisci.

Q: Se disattivo l'audio personalizzato?
A: Torna automaticamente ai suoni predefiniti.

Se provate l'addon e avete suggerimenti o trovate problemi, fatemi sapere!