# -*- coding: utf-8 -*-
"""
ChiudiPulito - Uscita pulita da Kodi
Service: monitora inattività e chiude automaticamente Kodi
"""

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ADDON_ICON = xbmcvfs.translatePath(ADDON.getAddonInfo('icon'))

class ChiudiPulitoMonitor(xbmc.Monitor):
    """Monitor per controllo inattività"""
    
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.idle_time = 0
        self.notifica_prima_mostrata = False
        self.notifica_30sec_mostrata = False
        xbmc.log('[ChiudiPulito] Service avviato correttamente', xbmc.LOGINFO)
    
    def riproduci_audio_personalizzato(self):
        """Riproduce l'audio personalizzato per l'avviso"""
        try:
            # Prima controlla se l'utente ha selezionato un file personalizzato
            custom_path = ADDON.getSetting('custom_sound_path')
            
            if custom_path and os.path.exists(custom_path):
                # Usa il file selezionato dall'utente
                audio_path = custom_path
                xbmc.log('[ChiudiPulito] Uso audio personalizzato utente (primo avviso)', xbmc.LOGDEBUG)
            else:
                # Fallback al file incluso nell'addon
                audio_path = os.path.join(ADDON_PATH, 'resources', 'sounds', 'avviso_1min.mp3')
                xbmc.log('[ChiudiPulito] Uso audio incluso nell\'addon (primo avviso)', xbmc.LOGDEBUG)
            
            if os.path.exists(audio_path):
                # Usa executebuiltin per riprodurre in background
                xbmc.executebuiltin(f'PlayMedia({audio_path})')
                xbmc.log(f'[ChiudiPulito] Audio riprodotto: {audio_path}', xbmc.LOGDEBUG)
            else:
                xbmc.log('[ChiudiPulito] File audio non trovato', xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f'[ChiudiPulito] Errore riproduzione audio: {str(e)}', xbmc.LOGERROR)
    
    def riproduci_audio_30sec(self):
        """Riproduce l'audio personalizzato per l'avviso 30 secondi"""
        try:
            # Prima controlla se l'utente ha selezionato un file personalizzato
            custom_path = ADDON.getSetting('custom_sound_30sec_path')
            
            if custom_path and os.path.exists(custom_path):
                # Usa il file selezionato dall'utente
                audio_path = custom_path
                xbmc.log('[ChiudiPulito] Uso audio personalizzato utente (30 secondi)', xbmc.LOGDEBUG)
            else:
                # Fallback al file incluso nell'addon
                audio_path = os.path.join(ADDON_PATH, 'resources', 'sounds', 'avviso_30sec.mp3')
                xbmc.log('[ChiudiPulito] Uso audio incluso nell\'addon (30 secondi)', xbmc.LOGDEBUG)
            
            if os.path.exists(audio_path):
                xbmc.executebuiltin(f'PlayMedia({audio_path})')
                xbmc.log(f'[ChiudiPulito] Audio 30sec riprodotto: {audio_path}', xbmc.LOGDEBUG)
            else:
                xbmc.log('[ChiudiPulito] File audio 30sec non trovato', xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f'[ChiudiPulito] Errore riproduzione audio 30sec: {str(e)}', xbmc.LOGERROR)
    
    def check_inactivity(self):
        """Controlla il tempo di inattività e chiude Kodi se necessario"""
        
        # Verifica se la chiusura automatica è abilitata
        if ADDON.getSetting('enable_auto_exit') != 'true':
            return
        
        # Non chiudere se sta riproducendo contenuti
        if xbmc.Player().isPlaying():
            self.idle_time = 0
            self.notifica_prima_mostrata = False
            self.notifica_30sec_mostrata = False
            return
        
        # Ottieni il tempo di inattività dell'utente
        idle_seconds = int(xbmc.getGlobalIdleTime())
        timeout_minutes = int(ADDON.getSetting('idle_timeout'))
        timeout_seconds = timeout_minutes * 60
        
        # Ottieni l'impostazione del suono
        suono_abilitato = ADDON.getSetting('enable_sound') == 'true'
        
        # Reset notifiche se l'utente torna attivo
        if idle_seconds < self.idle_time:
            self.notifica_prima_mostrata = False
            self.notifica_30sec_mostrata = False
            xbmc.log('[ChiudiPulito] Utente tornato attivo, reset timer', xbmc.LOGDEBUG)
        
        # Prima notifica (configurabile: 1, 2, 3 o 5 minuti prima)
        if ADDON.getSetting('enable_warning') == 'true':
            warning_minutes = int(ADDON.getSetting('warning_time'))
            warning_seconds = timeout_seconds - (warning_minutes * 60)
            
            if idle_seconds >= warning_seconds and not self.notifica_prima_mostrata:
                msg = f'Chiusura automatica tra {warning_minutes} minuto/i...'
                
                # Riproduce l'audio se il suono è abilitato
                if suono_abilitato:
                    # Controlla se usare l'audio personalizzato
                    use_custom = ADDON.getSetting('use_custom_sound') == 'true'
                    if use_custom:
                        self.riproduci_audio_personalizzato()
                        # Mostra notifica con icona addon, senza suono (l'audio è separato)
                        xbmcgui.Dialog().notification(
                            ADDON_NAME,
                            msg,
                            ADDON_ICON,
                            5000,
                            False
                        )
                    else:
                        # Usa il suono standard di Kodi con icona addon
                        xbmcgui.Dialog().notification(
                            ADDON_NAME,
                            msg,
                            ADDON_ICON,
                            5000,
                            True
                        )
                else:
                    # Notifica senza suono ma con icona addon
                    xbmcgui.Dialog().notification(
                        ADDON_NAME,
                        msg,
                        ADDON_ICON,
                        5000,
                        False
                    )
                
                self.notifica_prima_mostrata = True
                xbmc.log(f'[ChiudiPulito] Prima notifica: {warning_minutes} min alla chiusura', xbmc.LOGINFO)
        
        # Seconda notifica (sempre 30 secondi prima)
        warning_30sec = timeout_seconds - 30
        if idle_seconds >= warning_30sec and not self.notifica_30sec_mostrata:
            # Riproduce l'audio se il suono è abilitato
            if suono_abilitato:
                # Controlla se usare l'audio personalizzato per i 30 secondi
                use_custom_30sec = ADDON.getSetting('use_custom_sound_30sec') == 'true'
                if use_custom_30sec:
                    self.riproduci_audio_30sec()
                    # Mostra notifica con icona addon, senza suono (l'audio è separato)
                    xbmcgui.Dialog().notification(
                        ADDON_NAME,
                        'Chiusura automatica tra 30 secondi!',
                        ADDON_ICON,
                        5000,
                        False
                    )
                else:
                    # Usa il suono standard di Kodi con icona addon
                    xbmcgui.Dialog().notification(
                        ADDON_NAME,
                        'Chiusura automatica tra 30 secondi!',
                        ADDON_ICON,
                        5000,
                        True
                    )
            else:
                # Notifica senza suono ma con icona addon
                xbmcgui.Dialog().notification(
                    ADDON_NAME,
                    'Chiusura automatica tra 30 secondi!',
                    ADDON_ICON,
                    5000,
                    False
                )
            
            self.notifica_30sec_mostrata = True
            xbmc.log('[ChiudiPulito] Seconda notifica: 30 secondi alla chiusura', xbmc.LOGINFO)
        
        # Chiudi Kodi se è stato raggiunto il timeout
        if idle_seconds >= timeout_seconds:
            xbmc.log(f'[ChiudiPulito] Timeout raggiunto ({timeout_minutes} min). Chiusura automatica...', xbmc.LOGINFO)
            
            # Notifica finale (opzionale)
            if ADDON.getSetting('enable_notification') == 'true':
                xbmcgui.Dialog().notification(
                    ADDON_NAME,
                    'Chiusura automatica di Kodi...',
                    ADDON_ICON,
                    2000,
                    suono_abilitato
                )
            
            # Chiude Kodi
            xbmc.executebuiltin('Quit')
        
        # Aggiorna il tempo di inattività precedente
        self.idle_time = idle_seconds

def run_service():
    """Avvia il service monitor"""
    
    xbmc.log('[ChiudiPulito] Inizializzazione service...', xbmc.LOGINFO)
    monitor = ChiudiPulitoMonitor()
    
    # Loop principale: controlla ogni 5 secondi (per precisione con notifica 30 sec)
    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break
        
        monitor.check_inactivity()
    
    xbmc.log('[ChiudiPulito] Service terminato', xbmc.LOGINFO)

if __name__ == '__main__':
    run_service()
